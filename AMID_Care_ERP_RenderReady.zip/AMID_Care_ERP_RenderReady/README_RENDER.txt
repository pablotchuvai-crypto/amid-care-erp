AMID Care ERP - Versão pronta para Render

LOGIN INICIAL
Usuário: admin
Senha: admin

ARQUIVOS IMPORTANTES
app.py          -> sistema principal
requirements.txt-> dependências para Render
Procfile        -> comando para plataformas tipo Render
runtime.txt     -> versão do Python
render.yaml     -> configuração automática opcional do Render
assets/         -> logo e arquivos visuais
amid_clinica.db -> banco local SQLite inicial

CONFIGURAÇÃO NO RENDER
Build Command:
pip install -r requirements.txt

Start Command:
python app.py

Environment:
Python 3

OBSERVAÇÃO IMPORTANTE
Esta versão está pronta para subir como Web Service no Render.
No plano gratuito do Render, arquivos salvos em SQLite podem ser perdidos em reinicializações, porque o plano gratuito não possui disco persistente. Para uso real com dados permanentes, use plano pago com Persistent Disk ou migração para PostgreSQL.

PASSO A PASSO RESUMIDO
1. Crie um repositório no GitHub.
2. Envie todos os arquivos desta pasta para o repositório.
3. No Render, clique em New + > Web Service.
4. Conecte o GitHub e selecione o repositório.
5. Configure Build Command e Start Command conforme acima.
6. Clique em Deploy.
7. Aguarde o Render gerar o link público.

