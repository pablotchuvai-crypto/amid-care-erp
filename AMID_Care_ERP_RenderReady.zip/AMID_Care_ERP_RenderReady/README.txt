AMID CARE ERP - SISTEMA LOCAL PROFISSIONAL

COMO USAR
1. Extraia a pasta.
2. Windows: clique em INICIAR_WINDOWS.bat.
3. Mac/Linux: execute INICIAR_MAC_LINUX.sh ou rode python3 app.py.
4. Abra no navegador: http://localhost:8000

LOGIN INICIAL
Usuário: admin
Senha: admin

IMPORTANTE
- Entre em Configurações e altere a senha inicial antes de entregar à clínica.
- O sistema salva os dados em SQLite no arquivo amid_clinica.db.
- Backups automáticos diários ficam na pasta backups.
- Para acesso online/nuvem, precisa hospedar em VPS/servidor e configurar HTTPS/domínio.
- WhatsApp está integrado por link oficial. Automação total exige WhatsApp Business API/Meta.

MÓDULOS
Dashboard, Agenda, Pacientes, Prontuário/Evolução, Financeiro, Mensalidades, Pacotes,
WhatsApp, Assinatura Digital Local, Faltas, Convênios, Profissionais, Equipamentos,
Multiunidades, Documentos/LGPD, BI, Backup e Configurações.
