import os, json, sqlite3, hashlib, secrets, zipfile, csv, io, shutil
from datetime import datetime, date
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, unquote

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, 'amid_clinica.db')
ASSETS = os.path.join(BASE, 'assets')
BACKUPS = os.path.join(BASE, 'backups')
os.makedirs(BACKUPS, exist_ok=True)

TABLES = {
    'pacientes': ['nome','cpf','telefone','email','endereco','medico','diagnostico','observacoes','data_avaliacao','status'],
    'agenda': ['data','hora','paciente','telefone','profissional','tipo','status','reagendamento','observacoes'],
    'financeiro': ['data','tipo','categoria','descricao','valor','forma','status'],
    'mensalidades': ['aluno','plano','vencimento','valor','status','telefone','observacoes'],
    'pacotes': ['paciente','plano','aulas_total','aulas_feitas','validade','status'],
    'evolucao': ['data','paciente','queixa','objetivos','exercicios','evolucao','alta','profissional'],
    'faltas': ['data','paciente','motivo','reposicao_realizada','reposicao_pendente','observacoes'],
    'convenios': ['paciente','convenio','guia','emitida','faturada','paga','glosa','valor'],
    'profissionais': ['nome','cargo','telefone','email','valor_hora','comissao','status'],
    'equipamentos': ['equipamento','categoria','ultima_manutencao','proxima_manutencao','garantia','status','observacoes'],
    'unidades': ['nome','endereco','telefone','responsavel','status'],
    'documentos': ['paciente','tipo','descricao','arquivo','data','status'],
    'config': ['chave','valor'],
    'usuarios': ['nome','usuario','senha_hash','perfil','status']
}

LABELS = {
    'pacientes':'Pacientes','agenda':'Agenda','financeiro':'Financeiro','mensalidades':'Mensalidades','pacotes':'Controle de Pacotes','evolucao':'Prontuário / Evolução','faltas':'Faltas e Reposições','convenios':'Convênios','profissionais':'Profissionais','equipamentos':'Equipamentos','unidades':'Multiunidades','documentos':'Documentos / LGPD'
}

SESSIONS = {}

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def hash_password(password, salt=None):
    salt = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 150000)
    return f'pbkdf2_sha256${salt}${dk.hex()}'

def check_password(password, stored):
    if not stored:
        return False
    if stored == password:  # migração de versões antigas
        return True
    try:
        alg, salt, digest = stored.split('$')
        return secrets.compare_digest(hash_password(password, salt), stored)
    except Exception:
        return False

def init_db():
    c = db(); cur = c.cursor()
    for t, cols in TABLES.items():
        cur.execute(f"CREATE TABLE IF NOT EXISTS {t}(id INTEGER PRIMARY KEY AUTOINCREMENT, {', '.join([x+' TEXT' for x in cols])}, criado_em TEXT, atualizado_em TEXT)")
        existing = [r['name'] for r in cur.execute(f"PRAGMA table_info({t})")]
        for col in cols + ['criado_em','atualizado_em']:
            if col not in existing:
                cur.execute(f"ALTER TABLE {t} ADD COLUMN {col} TEXT")
    # migra usuario antigo com senha texto
    user_cols = [r['name'] for r in cur.execute('PRAGMA table_info(usuarios)')]
    if 'senha' in user_cols and 'senha_hash' in user_cols:
        for r in cur.execute('SELECT id, senha, senha_hash FROM usuarios').fetchall():
            if r['senha'] and not r['senha_hash']:
                cur.execute('UPDATE usuarios SET senha_hash=? WHERE id=?',(hash_password(r['senha']),r['id']))
    if cur.execute('SELECT COUNT(*) n FROM usuarios').fetchone()['n'] == 0:
        cur.execute("INSERT INTO usuarios(nome,usuario,senha_hash,perfil,status,criado_em,atualizado_em) VALUES(?,?,?,?,?,?,?)",
                    ('Administrador','admin',hash_password('admin'),'Administrador','Ativo',datetime.now().isoformat(),datetime.now().isoformat()))
    if cur.execute('SELECT COUNT(*) n FROM config').fetchone()['n'] == 0:
        defaults = {
            'clinica':'AMID Clínica de Saúde Integrada','telefone':'(47) 99999-9999','whatsapp':'5547999999999','email':'contato@amidclinica.com.br','endereco':'Endereço da clínica',
            'cor_principal':'#2f445b','cor_secundaria':'#b9d3e3','meta_inadimplencia':'5','meta_ocupacao':'80'
        }
        for k,v in defaults.items():
            cur.execute('INSERT INTO config(chave,valor,criado_em,atualizado_em) VALUES(?,?,?,?)',(k,v,datetime.now().isoformat(),datetime.now().isoformat()))
    seed(cur)
    c.commit(); c.close()
    auto_backup()

def seed(cur):
    if cur.execute('SELECT COUNT(*) n FROM pacientes').fetchone()['n'] > 0:
        return
    now = datetime.now().isoformat()
    pacientes = [
        ('Ana Paula Souza','111.222.333-44','47999990001','ana@email.com','Centro','Dr. Marcos','Lombalgia','Pilates clínico','2026-06-02','Ativo'),
        ('Carlos Alberto','222.333.444-55','47999990002','carlos@email.com','Timbó','Dra. Paula','Pós-operatório joelho','Fisioterapia 2x semana','2026-06-02','Ativo'),
        ('Mariana Silva','333.444.555-66','47999990003','mari@email.com','Bairro das Nações','Dr. Henrique','Dor cervical','RPG','2026-06-02','Ativo')]
    for p in pacientes: insert_row(cur,'pacientes',p,now)
    for a in [(date.today().isoformat(),'07:00','Ana Paula Souza','47999990001','Juliana Lima','Pilates','Confirmado','',''),(date.today().isoformat(),'08:00','Carlos Alberto','47999990002','Dr. Gabriel','Fisioterapia','Agendado','',''),(date.today().isoformat(),'09:00','Mariana Silva','47999990003','Juliana Lima','RPG','Confirmado','','')]: insert_row(cur,'agenda',a,now)
    for m in [('Ana Paula Souza','Pilates Ouro','2026-06-05','250.00','Pendente','47999990001',''),('Carlos Alberto','Fisioterapia','2026-06-03','300.00','Pendente','47999990002','')]: insert_row(cur,'mensalidades',m,now)
    for f in [(date.today().isoformat(),'entrada','Mensalidade','Ana Paula Souza','250.00','Pix','Pago'),(date.today().isoformat(),'saida','Energia','Conta de energia','320.00','Boleto','Pago')]: insert_row(cur,'financeiro',f,now)
    for pr in [('Juliana Lima','Fisioterapeuta/Pilates','47999991111','juliana@amid.com','60','30','Ativo'),('Dr. Gabriel','Fisioterapeuta','47999992222','gabriel@amid.com','80','35','Ativo')]: insert_row(cur,'profissionais',pr,now)
    for e in [('Reformer','Pilates','2026-05-01','2026-11-01','2027-01-01','Em uso',''),('Ultrassom','Fisioterapia','2026-04-10','2026-10-10','2026-12-01','Em uso','')]: insert_row(cur,'equipamentos',e,now)

def insert_row(cur,t,vals,now):
    cols = TABLES[t]
    cur.execute(f"INSERT INTO {t}({', '.join(cols)},criado_em,atualizado_em) VALUES({', '.join(['?']*len(cols))},?,?)", list(vals)+[now,now])

def all_rows(t):
    c=db(); rows=[dict(r) for r in c.execute(f'SELECT * FROM {t} ORDER BY id DESC')]; c.close(); return rows

def config():
    c=db(); d={r['chave']:r['valor'] for r in c.execute('SELECT chave,valor FROM config')}; c.close(); return d

def money(v):
    try: return float(str(v or '0').replace('.','').replace(',','.') if ',' in str(v) else str(v or '0'))
    except: return 0.0

def dashboard():
    ag=all_rows('agenda'); fin=all_rows('financeiro'); men=all_rows('mensalidades'); pac=all_rows('pacientes'); evo=all_rows('evolucao'); falt=all_rows('faltas')
    hoje=date.today().isoformat(); mes=date.today().strftime('%Y-%m')
    receitas=sum(money(x['valor']) for x in fin if x.get('tipo')=='entrada' and str(x.get('data','')).startswith(mes))
    despesas=sum(money(x['valor']) for x in fin if x.get('tipo')=='saida' and str(x.get('data','')).startswith(mes))
    inad=sum(money(x['valor']) for x in men if x.get('status')!='Pago')
    ocupacao = int(min(100, round((len([x for x in ag if x.get('data')==hoje]) / 10) * 100)))
    return {'agenda_hoje':len([x for x in ag if x.get('data')==hoje]), 'pacientes':len(pac),'receitas':receitas,'despesas':despesas,'lucro':receitas-despesas,'inadimplencia':inad,'ocupacao':ocupacao,'faltas':len(falt),'altas':len([x for x in evo if x.get('alta')=='Sim']),'agenda':ag[:8],'mensalidades':men[:8]}

def auto_backup():
    if not os.path.exists(DB): return
    today = date.today().isoformat()
    target = os.path.join(BACKUPS, f'backup_auto_{today}.zip')
    if os.path.exists(target): return
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        z.write(DB,'amid_clinica.db')
        logo = os.path.join(ASSETS,'logo_amid.jpeg')
        if os.path.exists(logo): z.write(logo,'assets/logo_amid.jpeg')

HTML = r'''<!DOCTYPE html><html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AMID Care ERP</title><style>
:root{--azul:#2f445b;--claro:#b9d3e3;--texto:#13294b;--bg:#f5f8fb}*{box-sizing:border-box}body{margin:0;font-family:Inter,Segoe UI,Arial,sans-serif;background:var(--bg);color:var(--texto)}.login{max-width:440px;margin:8vh auto;background:white;padding:28px;border-radius:22px;box-shadow:0 20px 60px #0f253d22;text-align:center}.login img{width:290px;max-width:100%;border-radius:16px}.login input{width:100%;padding:13px;border:1px solid #d6e0e8;border-radius:10px;margin:7px 0;font:inherit}.app{display:flex;min-height:100vh}.side{width:286px;background:linear-gradient(165deg,#2f445b,#102841);color:white;padding:22px;position:fixed;height:100vh;overflow:auto}.logo{width:100%;border-radius:16px;margin-bottom:18px;background:white}.nav button{width:100%;background:transparent;color:white;border:0;padding:12px 13px;text-align:left;border-radius:11px;font-size:14px;margin:3px 0;cursor:pointer}.nav button:hover,.nav button.on{background:rgba(255,255,255,.13)}.main{margin-left:286px;width:calc(100% - 286px)}header{height:72px;background:white;border-bottom:1px solid #e3ebf1;display:flex;align-items:center;justify-content:space-between;padding:0 28px;position:sticky;top:0;z-index:3}.content{padding:24px}.cards{display:grid;grid-template-columns:repeat(5,1fr);gap:14px}.card{background:white;border:1px solid #dfe7ef;border-radius:16px;padding:18px;box-shadow:0 6px 20px #1d355714}.card h3{margin:0 0 7px;font-size:13px;color:#567}.num{font-size:25px;font-weight:800}.grid{display:grid;grid-template-columns:2fr 1fr;gap:18px}.panel{background:white;border:1px solid #dfe7ef;border-radius:16px;padding:18px;margin-top:18px;box-shadow:0 5px 18px #1d355710}.table{width:100%;border-collapse:collapse}.table th,.table td{border-bottom:1px solid #eef3f7;padding:10px;text-align:left;font-size:13.5px;vertical-align:top}.btn{background:var(--azul);color:white;border:0;border-radius:10px;padding:10px 14px;cursor:pointer;text-decoration:none;display:inline-block}.btn2{background:#eef4f8;color:#20384f;border:0;border-radius:10px;padding:9px 12px;cursor:pointer;text-decoration:none;display:inline-block}.danger{background:#d9534f;color:white}.form{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:12px 0}.form input,.form select,.form textarea{padding:11px;border:1px solid #d6e0e8;border-radius:10px;font:inherit;width:100%}.form textarea{grid-column:span 3;min-height:76px}.actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.badge{padding:4px 9px;border-radius:999px;background:#e8f2fa;font-size:12px;display:inline-block}.hide{display:none}.mini{font-size:12px;color:#64778b}.footer{padding:20px 28px;background:#102841;color:#d8e5ee}.kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.sig{border:1px solid #ddd;border-radius:12px;background:white;max-width:100%}.topwarn{background:#fff8dd;border:1px solid #f2d675;border-radius:12px;padding:12px;margin-bottom:14px}.pill{border-radius:999px;padding:5px 9px;background:#edf6fa}.search{padding:10px;border:1px solid #d6e0e8;border-radius:10px;width:280px}.chart{height:14px;background:#edf3f8;border-radius:999px;overflow:hidden}.bar{height:100%;background:var(--azul)}@media(max-width:980px){.side{position:relative;width:100%;height:auto}.app{display:block}.main{margin-left:0;width:100%}.cards,.grid,.form,.kpis{grid-template-columns:1fr}.search{width:100%}}
</style></head><body><div id="login" class="login"><img src="/assets/logo_amid.jpeg"><h2>AMID Care ERP</h2><p class="mini">Sistema interno da clínica</p><input id="u" placeholder="Usuário" value="admin"><input id="p" placeholder="Senha" type="password" value="admin"><button class="btn" style="width:100%;margin-top:8px" onclick="logar()">Entrar</button><p class="mini">Usuário inicial: admin | Senha: admin</p></div>
<div id="app" class="app hide"><aside class="side"><img class="logo" src="/assets/logo_amid.jpeg"><div class="nav" id="nav"></div><p class="mini" style="color:#d5e2ec;margin-top:30px">AMID Clínica de Saúde Integrada<br>Versão profissional local 2.0</p></aside><main class="main"><header><h2 id="title">Dashboard</h2><div class="actions"><button class="btn2" onclick="open('/paciente')">App Paciente</button><button class="btn2" onclick="open('/fisio')">App Fisio</button><button class="btn2" onclick="logout()">Sair</button></div></header><section class="content" id="content"></section><div class="footer">AMID Care ERP • Sistema local com senha criptografada, backup, CSV, WhatsApp por link e módulos administrativos.</div></main></div>
<script>
const $=id=>document.getElementById(id);let token=localStorage.getItem('token')||'';let current='dashboard';
const labels={pacientes:'Pacientes',agenda:'Agenda',financeiro:'Financeiro',mensalidades:'Mensalidades',pacotes:'Controle de Pacotes',evolucao:'Prontuário / Evolução',faltas:'Faltas e Reposições',convenios:'Convênios',profissionais:'Profissionais',equipamentos:'Equipamentos',unidades:'Multiunidades',documentos:'Documentos / LGPD'};
const tables={pacientes:['nome','cpf','telefone','email','endereco','medico','diagnostico','observacoes','data_avaliacao','status'],agenda:['data','hora','paciente','telefone','profissional','tipo','status','reagendamento','observacoes'],financeiro:['data','tipo','categoria','descricao','valor','forma','status'],mensalidades:['aluno','plano','vencimento','valor','status','telefone','observacoes'],pacotes:['paciente','plano','aulas_total','aulas_feitas','validade','status'],evolucao:['data','paciente','queixa','objetivos','exercicios','evolucao','alta','profissional'],faltas:['data','paciente','motivo','reposicao_realizada','reposicao_pendente','observacoes'],convenios:['paciente','convenio','guia','emitida','faturada','paga','glosa','valor'],profissionais:['nome','cargo','telefone','email','valor_hora','comissao','status'],equipamentos:['equipamento','categoria','ultima_manutencao','proxima_manutencao','garantia','status','observacoes'],unidades:['nome','endereco','telefone','responsavel','status'],documentos:['paciente','tipo','descricao','arquivo','data','status']};
function br(c){return c.replaceAll('_',' ').replace(/\b\w/g,m=>m.toUpperCase())} function money(v){return 'R$ '+Number(v||0).toLocaleString('pt-BR',{minimumFractionDigits:2})}
async function api(url,opt={}){opt.headers=Object.assign({'Content-Type':'application/json','Authorization':'Bearer '+token},opt.headers||{});let r=await fetch(url,opt); if(r.status==401){logout();throw Error('sem login')} return await r.json()}
async function logar(){let r=await api('/api/login',{method:'POST',body:JSON.stringify({usuario:$('u').value,senha:$('p').value})}); if(r.ok){token=r.token;localStorage.setItem('token',token);$('login').classList.add('hide');$('app').classList.remove('hide');init()} else alert('Usuário ou senha inválidos')}
function logout(){localStorage.removeItem('token');token='';$('app').classList.add('hide');$('login').classList.remove('hide')}
function init(){let items=[['dashboard','🏠 Dashboard'],['agenda','📅 Agenda'],['pacientes','👥 Pacientes'],['evolucao','🩺 Prontuário'],['financeiro','💳 Financeiro'],['mensalidades','📆 Mensalidades'],['pacotes','📦 Pacotes'],['whatsapp','📱 WhatsApp'],['assinatura','✍️ Assinatura'],['faltas','❌ Faltas'],['convenios','🏥 Convênios'],['profissionais','👨‍⚕️ Profissionais'],['equipamentos','🛠️ Equipamentos'],['unidades','🏢 Multiunidades'],['documentos','📄 Documentos'],['bi','📊 BI'],['backup','☁️ Backup'],['config','⚙️ Configurações']];$('nav').innerHTML=items.map(i=>`<button id="n_${i[0]}" onclick="route('${i[0]}')">${i[1]}</button>`).join('');route('dashboard')}
function setTitle(t){document.querySelectorAll('.nav button').forEach(b=>b.classList.remove('on'));let b=$('n_'+t);if(b)b.classList.add('on');$('title').innerText=tables[t]?labels[t]:({'dashboard':'Dashboard','whatsapp':'WhatsApp','assinatura':'Assinatura Digital','bi':'BI e Gráficos','backup':'Backup','config':'Configurações'}[t]||t)}
function route(t){current=t;setTitle(t); if(t==='dashboard') return dash(); if(t==='whatsapp') return whats(); if(t==='assinatura') return assinatura(); if(t==='bi') return bi(); if(t==='backup') return backup(); if(t==='config') return config(); return crud(t)}
function tableHtml(data,cols){return `<table class="table"><thead><tr>${cols.map(c=>`<th>${br(c)}</th>`).join('')}</tr></thead><tbody>${data.map(r=>`<tr>${cols.map(c=>`<td>${r[c]||''}</td>`).join('')}</tr>`).join('')}</tbody></table>`}
async function dash(){let d=await api('/api/dashboard');$('content').innerHTML=`<div class="topwarn"><b>Atenção:</b> por segurança, altere a senha inicial em Configurações antes de entregar para a clínica.</div><div class="cards"><div class="card"><h3>Atendimentos hoje</h3><div class="num">${d.agenda_hoje}</div></div><div class="card"><h3>Pacientes ativos</h3><div class="num">${d.pacientes}</div></div><div class="card"><h3>Receitas do mês</h3><div class="num">${money(d.receitas)}</div></div><div class="card"><h3>Lucro líquido</h3><div class="num">${money(d.lucro)}</div></div><div class="card"><h3>Inadimplência</h3><div class="num">${money(d.inadimplencia)}</div></div></div><div class="grid"><div class="panel"><h3>Agenda de hoje</h3>${tableHtml(d.agenda,['data','hora','paciente','profissional','tipo','status'])}</div><div class="panel"><h3>Indicadores</h3><p>Taxa de ocupação <span class="pill">${d.ocupacao}%</span></p><div class="chart"><div class="bar" style="width:${d.ocupacao}%"></div></div><p>Faltas: <b>${d.faltas}</b></p><p>Altas: <b>${d.altas}</b></p><button class="btn" onclick="route('agenda')">Novo agendamento</button></div></div><div class="panel"><h3>Mensalidades pendentes</h3>${tableHtml(d.mensalidades,['aluno','plano','vencimento','valor','status','telefone'])}</div>`}
async function crud(t){let data=await api('/api/'+t), cols=tables[t]; $('content').innerHTML=`<div class="panel"><h3>Novo / Editar</h3><input type="hidden" id="id"><div class="form">${cols.map(c=>field(c)).join('')}</div><div class="actions"><button class="btn" onclick="save('${t}')">Salvar</button><button class="btn2" onclick="clearForm('${t}')">Limpar</button><input class="search" id="busca" placeholder="Pesquisar na tela" oninput="filterTable()"></div></div><div class="panel"><h3>${labels[t]}</h3><div class="actions"><a class="btn2" href="/api/export/${t}?token=${token}">Exportar CSV</a></div>${tableCrud(t,data,cols)}</div>`}
function field(c){let type=(c.includes('data')||c.includes('vencimento')||c.includes('validade')||c.includes('manutencao'))?'date':(c==='valor'||c.includes('total')||c.includes('feitas')?'number':'text'); if(['observacoes','evolucao','objetivos','exercicios','queixa','descricao'].includes(c))return `<textarea id="f_${c}" placeholder="${br(c)}"></textarea>`; return `<input id="f_${c}" type="${type}" placeholder="${br(c)}">`}
function tableCrud(t,data,cols){return `<table class="table" id="tb"><thead><tr>${cols.slice(0,7).map(c=>`<th>${br(c)}</th>`).join('')}<th>Ações</th></tr></thead><tbody>${data.map(r=>`<tr>${cols.slice(0,7).map(c=>`<td>${r[c]||''}</td>`).join('')}<td><button class="btn2" onclick='edit("${t}",${JSON.stringify(r).replaceAll("'","&#39;")})'>Editar</button> <button class="btn2 danger" onclick="del('${t}',${r.id})">Excluir</button></td></tr>`).join('')}</tbody></table>`}
function filterTable(){let q=$('busca').value.toLowerCase();document.querySelectorAll('#tb tbody tr').forEach(tr=>tr.style.display=tr.innerText.toLowerCase().includes(q)?'':'none')}
function clearForm(t){$('id').value='';tables[t].forEach(c=>{let el=$('f_'+c); if(el)el.value=''})} function edit(t,r){$('id').value=r.id;tables[t].forEach(c=>{let el=$('f_'+c); if(el)el.value=r[c]||''});scrollTo(0,0)}
async function save(t){let o={};tables[t].forEach(c=>o[c]=$('f_'+c).value);o.id=$('id').value; await api('/api/'+t,{method:'POST',body:JSON.stringify(o)});crud(t)} async function del(t,id){if(confirm('Excluir registro?')){await api('/api/'+t+'/'+id,{method:'DELETE'});crud(t)}}
function zap(fone,msg){let n=(fone||'').replace(/\D/g,''); if(!n.startsWith('55'))n='55'+n; open('https://wa.me/'+n+'?text='+encodeURIComponent(msg),'_blank')}
async function whats(){let pac=await api('/api/pacientes');let men=await api('/api/mensalidades');$('content').innerHTML=`<div class="panel"><h3>WhatsApp</h3><p>Integração pronta por link oficial do WhatsApp. Para automação real 100%, configurar API oficial da Meta em produção.</p><div class="actions"><button class="btn" onclick="zap(prompt('Telefone com DDD:'),'Olá! Lembramos que seu atendimento na AMID está agendado. Confirma presença?')">Lembrete de consulta</button><button class="btn" onclick="zap(prompt('Telefone com DDD:'),'Olá! Sua mensalidade da AMID está próxima do vencimento. Qualquer dúvida estamos à disposição.')">Cobrança amigável</button><button class="btn2" onclick="zap(prompt('Telefone com DDD:'),'Olá! A AMID agradece seu atendimento. Poderia avaliar sua experiência?')">Pesquisa de satisfação</button></div></div><div class="grid"><div class="panel"><h3>Pacientes</h3>${tableHtml(pac,['nome','telefone','diagnostico','status'])}</div><div class="panel"><h3>Mensalidades</h3>${tableHtml(men,['aluno','telefone','plano','valor','vencimento','status'])}</div></div>`}
function assinatura(){$('content').innerHTML=`<div class="panel"><h3>Assinatura digital local</h3><p>O paciente pode assinar contratos, LGPD, avaliação inicial e termo de responsabilidade.</p><canvas id="canvas" width="760" height="260" class="sig"></canvas><br><br><button class="btn" onclick="baixarAss()">Baixar assinatura</button> <button class="btn2" onclick="assinatura()">Limpar</button></div>`;let c=$('canvas'),ctx=c.getContext('2d'),draw=false;ctx.lineWidth=2;function pos(e){let r=c.getBoundingClientRect(),x=(e.touches?e.touches[0].clientX:e.clientX)-r.left,y=(e.touches?e.touches[0].clientY:e.clientY)-r.top;return{x,y}}function start(e){draw=true;let p=pos(e);ctx.beginPath();ctx.moveTo(p.x,p.y);e.preventDefault()}function move(e){if(!draw)return;let p=pos(e);ctx.lineTo(p.x,p.y);ctx.stroke();e.preventDefault()}c.onmousedown=start;c.onmousemove=move;c.onmouseup=()=>draw=false;c.onmouseleave=()=>draw=false;c.ontouchstart=start;c.ontouchmove=move;c.ontouchend=()=>draw=false}
function baixarAss(){let a=document.createElement('a');a.download='assinatura_amid.png';a.href=$('canvas').toDataURL();a.click()}
async function bi(){let d=await api('/api/dashboard');$('content').innerHTML=`<div class="panel"><h3>BI e gráficos</h3><div class="kpis"><div class="card"><h3>Receitas</h3><div class="num">${money(d.receitas)}</div></div><div class="card"><h3>Despesas</h3><div class="num">${money(d.despesas)}</div></div><div class="card"><h3>Lucro</h3><div class="num">${money(d.lucro)}</div></div><div class="card"><h3>Ocupação</h3><div class="num">${d.ocupacao}%</div></div><div class="card"><h3>Faltas</h3><div class="num">${d.faltas}</div></div><div class="card"><h3>Altas</h3><div class="num">${d.altas}</div></div></div><p class="mini">Relatórios podem ser impressos/salvos em PDF pelo navegador.</p><button class="btn" onclick="print()">Imprimir / Salvar PDF</button></div>`}
function backup(){$('content').innerHTML=`<div class="panel"><h3>Backup</h3><p>O sistema cria um backup automático diário na pasta <b>backups</b>. Baixe também um backup manual e salve no Google Drive, OneDrive ou pendrive.</p><a class="btn" href="/api/backup?token=${token}">Baixar backup completo</a></div>`}
async function config(){let cfg=await api('/api/config');$('content').innerHTML=`<div class="panel"><h3>Configurações da clínica</h3><div class="form">${Object.keys(cfg).map(k=>`<input id="cfg_${k}" placeholder="${br(k)}" value="${cfg[k]||''}">`).join('')}</div><button class="btn" onclick="saveConfig(${JSON.stringify(Object.keys(cfg))})">Salvar configurações</button></div><div class="panel"><h3>Alterar senha do administrador</h3><div class="form"><input id="oldpass" type="password" placeholder="Senha atual"><input id="newpass" type="password" placeholder="Nova senha"><input id="newpass2" type="password" placeholder="Repita a nova senha"></div><button class="btn" onclick="changePass()">Alterar senha</button></div>`}
async function saveConfig(keys){let o={};keys.forEach(k=>o[k]=$('cfg_'+k).value);await api('/api/config',{method:'POST',body:JSON.stringify(o)});alert('Configurações salvas')}
async function changePass(){if($('newpass').value!==$('newpass2').value)return alert('As senhas não conferem');let r=await api('/api/change-password',{method:'POST',body:JSON.stringify({old:$('oldpass').value,new:$('newpass').value})});alert(r.ok?'Senha alterada':'Senha atual incorreta')}
if(token){$('login').classList.add('hide');$('app').classList.remove('hide');init()}
</script></body></html>'''

PATIENT = '''<!doctype html><html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AMID Paciente</title><style>body{font-family:Segoe UI,Arial;background:#f5f8fb;color:#13294b;margin:0}.box{max-width:760px;margin:auto;padding:24px}.card{background:white;border-radius:18px;padding:22px;margin:14px 0;box-shadow:0 8px 26px #0001}.logo{width:280px;max-width:100%;border-radius:16px}.btn{background:#2f445b;color:white;padding:12px 15px;border:0;border-radius:10px;text-decoration:none;display:inline-block;margin:5px}</style></head><body><div class="box"><img class="logo" src="/assets/logo_amid.jpeg"><div class="card"><h2>App do Paciente</h2><p>Área rápida para confirmação de horário, contato, mensalidade e orientações.</p><a class="btn" href="https://wa.me/5547999999999?text=Olá%20AMID,%20quero%20confirmar%20meu%20atendimento">Confirmar pelo WhatsApp</a><a class="btn" href="/">Voltar</a></div></div></body></html>'''
FISIO = '''<!doctype html><html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AMID Fisioterapeuta</title><style>body{font-family:Segoe UI,Arial;background:#f5f8fb;color:#13294b;margin:0}.box{max-width:760px;margin:auto;padding:24px}.card{background:white;border-radius:18px;padding:22px;margin:14px 0;box-shadow:0 8px 26px #0001}.logo{width:280px;max-width:100%;border-radius:16px}.btn{background:#2f445b;color:white;padding:12px 15px;border:0;border-radius:10px;text-decoration:none;display:inline-block;margin:5px}</style></head><body><div class="box"><img class="logo" src="/assets/logo_amid.jpeg"><div class="card"><h2>App do Fisioterapeuta</h2><p>Use o sistema principal para agenda do dia, prontuário, evolução, faltas e produtividade.</p><a class="btn" href="/">Entrar no sistema</a></div></div></body></html>'''

class Handler(BaseHTTPRequestHandler):
    def _headers(self, code=200, content_type='application/json; charset=utf-8', extra=None):
        self.send_response(code); self.send_header('Content-Type', content_type); self.send_header('Cache-Control','no-store')
        if extra:
            for k,v in extra.items(): self.send_header(k,v)
        self.end_headers()
    def send(self, data, code=200, content_type='application/json; charset=utf-8', extra=None):
        self._headers(code, content_type, extra)
        if isinstance(data, str): data=data.encode('utf-8')
        self.wfile.write(data)
    def auth(self):
        if self.path.startswith('/api/login') or self.path in ['/', '/paciente', '/fisio'] or self.path.startswith('/assets/'):
            return True
        token = self.headers.get('Authorization','').replace('Bearer ','')
        if not token:
            token = urlparse(self.path).query.replace('token=','') if 'token=' in urlparse(self.path).query else ''
        return token in SESSIONS
    def do_GET(self):
        p = urlparse(self.path).path
        if p == '/': return self.send(HTML, content_type='text/html; charset=utf-8')
        if p == '/paciente': return self.send(PATIENT, content_type='text/html; charset=utf-8')
        if p == '/fisio': return self.send(FISIO, content_type='text/html; charset=utf-8')
        if p.startswith('/assets/'):
            fn=os.path.join(ASSETS, os.path.basename(unquote(p)))
            if os.path.exists(fn): return self.send(open(fn,'rb').read(), content_type='image/jpeg')
        if not self.auth(): return self.send({'erro':'não autorizado'},401)
        if p == '/api/dashboard': return self.send(json.dumps(dashboard(),ensure_ascii=False))
        if p == '/api/config': return self.send(json.dumps(config(),ensure_ascii=False))
        if p == '/api/backup':
            auto_backup(); z=os.path.join(BACKUPS, f'backup_manual_{datetime.now().strftime("%Y%m%d_%H%M%S")}.zip')
            with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as zp:
                if os.path.exists(DB): zp.write(DB,'amid_clinica.db')
                for root,_,files in os.walk(ASSETS):
                    for f in files: zp.write(os.path.join(root,f), os.path.relpath(os.path.join(root,f), BASE))
            return self.send(open(z,'rb').read(), content_type='application/zip', extra={'Content-Disposition':'attachment; filename=backup_amid.zip'})
        if p.startswith('/api/export/'):
            t=p.split('/')[-1]
            if t not in TABLES: return self.send({'erro':'tabela inválida'},404)
            output=io.StringIO(); cols=['id']+TABLES[t]+['criado_em','atualizado_em']; w=csv.DictWriter(output, fieldnames=cols, delimiter=';'); w.writeheader()
            for r in all_rows(t): w.writerow({c:r.get(c,'') for c in cols})
            return self.send(output.getvalue(), content_type='text/csv; charset=utf-8', extra={'Content-Disposition':f'attachment; filename={t}.csv'})
        if p.startswith('/api/'):
            t=p.split('/')[2]
            if t in TABLES and t not in ['usuarios','config']:
                return self.send(json.dumps(all_rows(t),ensure_ascii=False))
        return self.send({'erro':'não encontrado'},404)
    def do_POST(self):
        p=urlparse(self.path).path; length=int(self.headers.get('Content-Length',0)); data=json.loads(self.rfile.read(length) or b'{}')
        if p == '/api/login':
            c=db(); r=c.execute('SELECT * FROM usuarios WHERE usuario=? AND status="Ativo"',(data.get('usuario'),)).fetchone(); c.close()
            if r and check_password(data.get('senha',''), r['senha_hash']):
                token=secrets.token_urlsafe(32); SESSIONS[token]=r['usuario']; return self.send(json.dumps({'ok':True,'token':token}))
            return self.send(json.dumps({'ok':False}))
        if not self.auth(): return self.send({'erro':'não autorizado'},401)
        if p == '/api/config':
            c=db(); cur=c.cursor(); now=datetime.now().isoformat()
            for k,v in data.items():
                ex=cur.execute('SELECT id FROM config WHERE chave=?',(k,)).fetchone()
                if ex: cur.execute('UPDATE config SET valor=?, atualizado_em=? WHERE chave=?',(v,now,k))
                else: cur.execute('INSERT INTO config(chave,valor,criado_em,atualizado_em) VALUES(?,?,?,?)',(k,v,now,now))
            c.commit(); c.close(); return self.send({'ok':True})
        if p == '/api/change-password':
            user = SESSIONS.get(self.headers.get('Authorization','').replace('Bearer ',''))
            c=db(); cur=c.cursor(); r=cur.execute('SELECT * FROM usuarios WHERE usuario=?',(user,)).fetchone()
            if r and check_password(data.get('old',''), r['senha_hash']):
                cur.execute('UPDATE usuarios SET senha_hash=?, atualizado_em=? WHERE usuario=?',(hash_password(data.get('new','')), datetime.now().isoformat(), user)); c.commit(); c.close(); return self.send({'ok':True})
            c.close(); return self.send({'ok':False})
        if p.startswith('/api/'):
            t=p.split('/')[2]
            if t in TABLES and t not in ['usuarios','config']:
                cols=TABLES[t]; now=datetime.now().isoformat(); c=db(); cur=c.cursor(); vals=[data.get(x,'') for x in cols]
                if data.get('id'):
                    cur.execute(f"UPDATE {t} SET {', '.join([x+'=?' for x in cols])}, atualizado_em=? WHERE id=?", vals+[now,data.get('id')])
                else:
                    cur.execute(f"INSERT INTO {t}({', '.join(cols)},criado_em,atualizado_em) VALUES({', '.join(['?']*len(cols))},?,?)", vals+[now,now])
                c.commit(); c.close(); return self.send({'ok':True})
        return self.send({'erro':'não encontrado'},404)
    def do_DELETE(self):
        if not self.auth(): return self.send({'erro':'não autorizado'},401)
        parts=urlparse(self.path).path.split('/')
        if len(parts)==4 and parts[1]=='api' and parts[2] in TABLES and parts[2] not in ['usuarios','config']:
            c=db(); c.execute(f'DELETE FROM {parts[2]} WHERE id=?',(parts[3],)); c.commit(); c.close(); return self.send({'ok':True})
        return self.send({'erro':'não encontrado'},404)

def run():
    init_db()
    port = int(os.environ.get('PORT', '8000'))
    print(f'AMID Care ERP iniciado em http://0.0.0.0:{port}')
    HTTPServer(('0.0.0.0', port), Handler).serve_forever()
if __name__ == '__main__': run()
